#include <iostream>
#include <string>
#include "Parser.h"
#include "Scaner.h"

using namespace std;

int main()
{
    /*string str = "testscan.txt";
    Scaner s(str);
    s.test();
	cin.get();*/
	/*string str = "testscan.txt";
	Parser parsr(str);
	parsr.test();
	cin.get();*/
	PredictMethod p;
	p.test();
	cin.get();
}
