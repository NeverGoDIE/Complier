#ifndef Parser_H
#define Parser_H

#include "Scaner.h"
#include <set>
#include <map>
#include <stack>


#define MAX 507


using namespace std;

class WF {
private:
	string left;
	set<string> right;
public:
	WF(char s[]) {
		left = s;
	}
	void print();
	void insert( char s[] );
	string getLeft() {
		return left;
	}
	set<string> getRight() {
		return right;
	}
};

class PredictMethod {
private:
	map<string, set<char>> first;
	map<string, set<char>> follow;
	map<string, int> VN_dic;
	vector<WF> VN_set;
	bool used[MAX];
	string filename = "testParse.txt";
	vector<map<char, string>> predict_table;
	vector<char> letter;
	Scaner scn = Scaner("testscan.txt");

public:
	void dfs(int x);
	void make_first();

	void append(const string& str1, const string& str2);
	void make_follow();

	bool check_first(const string& text, char ch);
	bool check_follow(const string& text, char ch);
	void make_table();

	bool analyze(vector<wordtype> input);
	string trans2VT(wordtype w);

	void test();
};

#endif